
function Home() {
    return(
        <div>
            <h1>Home</h1>
            <p>Ruta incial</p>
        </div>
    )
}

export default Home;