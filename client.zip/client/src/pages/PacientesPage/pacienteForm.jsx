import { usePacientes } from "../../context/pacientesContext";
import { Formik, Form } from "formik";

import { useEffect, useState } from "react";
import CardSeleccionCiudad from "../../components/CardSelecCiudad";
import CardSeleccionBarrio from "../../components/cardSeleccionBarrio";
import { Button } from "@mui/material";
import { styled } from "@mui/system";

const Titulo = styled("div")({
  fontSize: "40px",
  fontWeight: "bold",
  display: "flex",
  justifyContent: "center",
});

const Botones = styled("div")({
  display: "flex",
  justifyContent: "center",
  gap: "20%",
});

const Formulario = styled("div")({
  display: "grid",
  gridTemplateColumns: "1fr 1fr",
  paddingBottom: "3%",
});

function PacientesForm({ pacienteId, handleCloseModal }) {

  const { CrearPaciente, ListarPaciente, ActualizarPaciente } = usePacientes();

  const [pacientes, setPacientes] = useState({
    nombre: "",
    apellido: "",
    ci: "",
    fechaNac: "",
    sexo: "",
    sangre: "",
    barrio: "",
    ciudad: "",
    direccion: "",
    telefono: "",
    usuarioId: "",
  });

  useEffect(() => {
    const loadPacientes = async () => {
      if (pacienteId) {
        const paciente = await ListarPaciente(pacienteId);
        const date = new Date(paciente.fechaNac);
        const year = date.getFullYear();
        const month = date.getMonth() + 1;
        const day = date.getDate();
        const formattedDate = `${year}-${month
          .toString()
          .padStart(2, "0")}-${day.toString().padStart(2, "0")}`;

        setPacientes({
          nombre: paciente.nombre,
          apellido: paciente.apellido,
          ci: paciente.ci,
          fechaNac: formattedDate,
          sexo: paciente.sexo,
          sangre: paciente.sangre,
          barrio: paciente.barrio || "",
          barrioId: paciente.barrioId,
          ciudad: paciente.ciudad || "",
          ciudadId: paciente.ciudadId,
          telefono: paciente.telefono,
          direccion: paciente.direccion,
          fechaReg: formattedDate,
          ultTurno: formattedDate,

          usuarioId: paciente.usuarioId,
        });
      }
    };

    loadPacientes();
    
  }, [pacienteId, ListarPaciente]);

  function renderSelect() {
    if (ciudad.length === 0)
      return <option value="">No hay Ciudades</option>;
    return <CardSeleccionCiudad ciudades={ciudad} />;
  }
  function renderSelectBarrio() {
    if (barrio.length === 0)
      return <option value="">No hay Barrio</option>;
    return <CardSeleccionBarrio barrios={barrio} />;
  }
  return (
    <div>
      <Titulo>{pacienteId ? "Editar Paciente" : "Crear Paciente"}</Titulo>

      <div>
        <Formik
          initialValues={pacientes}
          enableReinitialize={true}
          onSubmit={async (values, actions) => {
            console.log(values);
            if (pacienteId) {
              await ActualizarPaciente(pacienteId, values);
              console.log(values);
              handleCloseModal();
            } else {
              await CrearPaciente(values);
            }
            actions.resetForm();
          }}
        >
          {({ handleChange, handleSubmit, values }) => (
            <Form onSubmit={handleSubmit}>
              <Formulario>
                <label>Nombre:</label>
                <input
                  type="text"
                  value={values.nombre}
                  name="nombre"
                  onChange={handleChange}
                />

                <label>Apellido</label>
                <input
                  type="text"
                  value={values.apellido}
                  name="apellido"
                  onChange={handleChange}
                />

                {!pacienteId && (
                  <>
                    <label>CI:</label>
                    <input
                      type="text"
                      value={values.ci}
                      name="ci"
                      onChange={handleChange}
                    />
                  </>
                )}

                <label>F. Nacimiento:</label>
                <input
                  type="date"
                  value={values.fechaNac}
                  name="fechaNac"
                  onChange={handleChange}
                />
                 <label>Sexo</label>
                <input
                  type="text"
                  value={values.apellido}
                  name="sexo"
                  onChange={handleChange}
                />
                 <label>Sangre</label>
                <input
                  type="text"
                  value={values.apellido}
                  name="sangre"
                  onChange={handleChange}
                />
             <label>Barrio:</label>
                 {pacienteId && (
                  <select
                    name="pacienteId"
                    value={values.pacienteId}
                    onChange={handleChange}
                  >
                    <option initialvalues={values.pacienteId}>
                      {values.barrio}
                    </option>
                    {renderSelectBarrio()}
                  </select>
                )}
                 <label>Ciuadad:</label>
                 {pacienteId && (
                  <select
                    name="pacienteId"
                    value={values.pacienteId}
                    onChange={handleChange}
                  >
                    <option initialvalues={values.pacienteId}>
                      {values.ciudad}
                    </option>
                    {renderSelect()}
                  </select>
                )}
                <label>Telefono:</label>
                <input
                  type="text"
                  value={values.telefono}
                  name="telefono"
                  onChange={handleChange}
                />

                <label>Direccion:</label>
                <input
                  type="text"
                  value={values.direccion}
                  name="direccion"
                  onChange={handleChange}
                />
                <label>F.Reg:</label>
                <input
                  type="date"
                  value={values.fechaReg}
                  name="fechaReg"
                  onChange={handleChange}
                />
                 <label>ultimo Turno:</label>
                <input
                  type="date"
                  value={values.ultTurno}
                  name="ultTurno"
                  onChange={handleChange}
                />
                <label>Usuario:</label>
                <select
                  name="usuarioId"
                  value={values.usuarioId}
                  onChange={handleChange}
                >
                  <option initialvalues="" hidden></option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                </select>
                
              </Formulario>

              <Botones>
                <Button variant="contained" type="submit" color="success">
                  Guardar
                </Button>
                <Button
                  type="button"
                  variant="outlined"
                  color="error"
                  onClick={handleCloseModal}
                >
                  Cancelar
                </Button>
              </Botones>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
}

export default PacientesForm;
